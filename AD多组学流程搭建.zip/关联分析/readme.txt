原始文件（读入）：
GSE158995_DEG_Up_Down.txt
GSE203554_DEG_Up_Down.txt
GSE230469_DEG_Up_Down.txt
Prot_DEP_Up_Down.txt

脚本：
关联分析.R

取交集整理后：
RNA_Protein_Info.csv

Up-Down展示：
RNA_Protein_Plot.pdf

GO富集注释：
RNA_prot_GO富集注释.csv

GO富集条形图、气泡图：
top10_GO_bar.pdf
top10_GO_point.pdf