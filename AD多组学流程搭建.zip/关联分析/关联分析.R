setwd("D:/AD实训/关联分析")
rm(list = ls())

# 加载必要的库
library(dplyr)
library(ggplot2)
library(ggrepel)

# 读入数据
RNA_1 <- read.table("GSE230469_DEG_Up_Down.txt")
RNA_2 <- read.table("GSE158995_DEG_Up_Down.txt")
RNA_3 <- read.table("GSE203554_DEG_Up_Down.txt")

protein <- read.table("Prot_DEP_Up_Down.txt")

# 定义一个空列表来存储合并后的数据框
combined_data_list <- list()

# 使用循环分别合并RNA_1、RNA_2、RNA_3与protein
rna_list <- list(RNA_1, RNA_2, RNA_3)

for (i in seq_along(rna_list)) {
  combined_data_list[[i]] <- merge(rna_list[[i]], protein,
                                   by.x = "ENTREZID",
                                   by.y = "ENTREZID",
                                   suffixes = c("_RNA","_Protein"),
                                   all.x = FALSE,
                                   all.y = FALSE)
}

# 合并RNA与Protein数据
# 发现11820和69981有重复（各一个），先保留，不需要可以删去
combine <- bind_rows(combined_data_list)

# 保存合并后的数据
write.csv(combine,"RNA_Protein_Info.csv",row.names=FALSE)


#####--UP-DOWN关联--#####
# 对数据进行分组
# 生成显著上下调数据标签
combine$part <- case_when(combine$Group_RNA == "Up" & combine$Group_Protein == "Up" ~ "part1",
                       combine$Group_RNA == "Up" & combine$Group_Protein == "Down" ~ "part2",
                       combine$Group_RNA == "Down" & combine$Group_Protein == "Down" ~ "part3",
                       combine$Group_RNA == "Down" & combine$Group_Protein == "Up" ~ "part4")
head(combine)

# 绘图
p0 <- ggplot(combine, aes(x = log2FoldChange_Protein, y = log2FoldChange_RNA, color = part))+
  geom_point(size = 1.5) +
  geom_hline(yintercept = c(1,-1), linetype = "dashed", color = "gray") +
  geom_vline(xintercept = c(1,-1), linetype = "dashed", color = "gray") +
  geom_text(aes(label = ENTREZID), nudge_x = 0.2, check_overlap = TRUE) + 
  xlim(-1.5, 3) +  ylim(-10, 10) +
  scale_color_manual(values = c("#339933", "#FF9900", "#3366CC", "#996600"),
                     labels = c("Up-Up","Up-Down", "Down-Down", "Down-Up")) +
  labs(color = "RNA-Protein")

# 11838、64011、11820(1个)的logFC_RNA太大，排除图外

# 显示图形
p0

# 保存图形
pdf("RNA_Protein_Plot.pdf", width = 8, height = 10)
print(p0)
dev.off()



#####--GO富集--#####
rm(list = ls())
library(dplyr)
library(org.Mm.eg.db)
library(clusterProfiler)
library(DOSE)
library(ggplot2)
library(ggrepel)

# 读取数据
comb <- read.csv("RNA_Protein_Info.csv")

# 查看可转换的ID类型
columns(org.Mm.eg.db)

# GO富集
GO_all_diff <- enrichGO(gene = comb$ENTREZID,
                        OrgDb = org.Mm.eg.db,
                        ont = "ALL", 
                        pAdjustMethod = "BH",
                        pvalueCutoff = 0.05,
                        qvalueCutoff = 0.05,
                        minGSSize = 10,
                        maxGSSize = 500,
                        readable = T)

View(GO_all_diff@result)

# 导出
write.csv(x = GO_all_diff,file = "RNA_prot_GO富集注释.csv")

# TOP10富集条形图绘制
go_enrich<-read.csv(file="RNA_prot_GO富集注释.csv")

# 对每个ONTOLOGY类别，根据p.adjust值选取前十个
top_enrich <- go_enrich %>%
  group_by(ONTOLOGY) %>%
  slice_max(p.adjust, n = 10, with_ties = FALSE) %>%
  ungroup()

# 绘制纵向柱状图
pdf("top10_GO_bar.pdf", width = 8, height = 8)

p1 <- ggplot(top_enrich,
             aes(x=Description, y=Count, fill=ONTOLOGY)) + # x、y轴定义；根据ONTOLOGY填充颜色
  geom_bar(stat="identity", width=0.8) +  # 柱状图宽度
  scale_fill_manual(values = c("#6666FF", "#33CC33", "#FF6666")) +  # 柱状图填充颜色
  coord_flip() +  # 让柱状图变为纵向
  xlab("GO term") +  # x轴标签
  ylab("Gene Number") +  # y轴标签
  labs(title = "GO Terms Enrich") +  # 设置标题
  theme_bw()

# 根据ONTOLOGY分类信息添加分组框
p1 + facet_grid(ONTOLOGY~., scale = 'free_y', space = 'free_y')

dev.off()


# 气泡图
pdf("top10_GO_point.pdf", width = 8, height = 8)
P2 <- ggplot(top_enrich,
             aes(y=Description,x=Count))+
  geom_point(aes(size=Count,color=pvalue))+
  scale_color_gradient(low = "red",high ="blue")+
  labs(color=expression(PValue,size="Count"), 
       x="Gene Ratio",y="GO term",title="GO Enrichment")+
  theme_bw()
# 根据ONTOLOGY分类信息添加分组框#
P2 + facet_grid(ONTOLOGY~., scale = 'free_y', space = 'free_y')

dev.off()

