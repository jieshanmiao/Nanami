setwd("D:/AD实训/RNAseq/RNAseq-2")
rm(list = ls())

# 加载必要的包
library(limma)
library(dplyr)
library(sva)
library(clusterProfiler)
library(org.Mm.eg.db)



# 读取数据
data <- read.table("GSE158995_mRNA_normalized.txt", sep = '\t', header = T)

# 合并重复行
data_org <- avereps(data, data$Gene_Name)

data_org <- as.data.frame(data_org)

# 取genename为行名
rownames(data_org) <- data_org$Gene_Name
data_org <- data_org[ , -1]
dim(data_org) 


#####差异分析#####
# 根据治疗信息分组，取出对应的列
data_WT <- data_org[, c(1:3)]
data_APP <- data_org[, c(4:6)]

group <- c(rep('WT', ncol(data_WT)), rep('APP', ncol(data_APP)))
group <- factor(group, levels = c("WT", "APP"))

table(group)

# 创建设计矩阵，指定组别信息
design <- model.matrix(~0 + factor(group))
colnames(design) = levels(factor(group))
rownames(design) = colnames(data_org)

# 转换非数值型列为数值型
data_org[] <- lapply(data_org, function(x) as.numeric(as.character(x)))

# 再次检查数据类型，确保所有列都是数值型
str(data_org)

# 使用线性模型进行拟合
fit <- lmFit(data_org, design)

# 说明是谁比谁
con <- paste(rev(levels(group)), collapse = "-")
con

# 创建对比矩阵
cont.matrix <- makeContrasts(contrasts = c(con), levels = design)
fit2 <- contrasts.fit(fit, cont.matrix)
fit2 <- eBayes(fit2)

# 获取差异表达基因结果
tempOutput <- topTable(fit2, coef = con, n = Inf)

# 去除缺失值
DEG_limma_voom <- na.omit(tempOutput)
head(DEG_limma_voom)

# 将差异表达基因结果保存到 Rdata 文件中
save(DEG_limma_voom, file = './GSE158995_DEG_limma.Rdata')

# 这里看res里，padj很显著的不多
# 不清楚后续画图的同学如何选择，所以把pvalue也加进来
DEG_res = DEG_limma_voom[,c(1,4,5)]
colnames(DEG_res) = c('log2FoldChange','pvalue','padj')

#####--后续分析数据处理--#####
# ID转换
DEG_res$symbol <- row.names(DEG_res)
map <- bitr(DEG_res$symbol, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Mm.eg.db, drop = TRUE)
#提示少量无法映射

DEG_res <- merge(DEG_res,map,by.x = "symbol",by.y = "SYMBOL")

# 这里log2FoldChange筛的狠一点，从这里看显著性还不错
# 配着pvalue<0.05,up有56
DEG_res$Group <- ifelse(DEG_res$log2FoldChange > 3,"Up",ifelse(DEG_res$log2FoldChange<(-3),"Down","none"))
head(DEG_res)
table(DEG_res$Group)

# 关联分析数据准备
DEG_res <- DEG_res %>% select("ENTREZID", "symbol", "log2FoldChange", "pvalue", "padj", "Group")

# 存数据用于后续分析
# 所有基因结果
write.table(DEG_res, file = "GSE158995_DEG_all.txt", sep = "\t")

# 差异基因结果
up_down <- DEG_res %>% filter(Group == "Up" | Group == "Down")
write.table(up_down, file = "GSE158995_DEG_Up_Down.txt", sep = "\t")



#####--GO富集分析--#####
# 用的是Mus musculus
library(org.Mm.eg.db)
library(clusterProfiler)
library(DOSE)

#差异基因集提取
up <- DEG_res[,1][DEG_res$Group == "Up"]#差异上调
down <- DEG_res[,1][DEG_res$Group == "Down"]#差异下调

#所有差异基因的ENTREZID
diff <- c(up, down)

#查看可转换的ID类型
columns(org.Mm.eg.db)

# GO富集
GO_all_diff <- enrichGO(gene = diff,
                        OrgDb = org.Mm.eg.db,
                        ont = "ALL", 
                        pAdjustMethod = "BH",
                        pvalueCutoff = 0.05,
                        qvalueCutoff = 0.05,
                        minGSSize = 10,
                        maxGSSize = 500,
                        readable = T)

View(GO_all_diff@result)

# 导出
write.csv(x = GO_all_diff,file = "GSE158995_GO富集注释.csv")


#####--基因集富集分析--#####
rm(list = ls())
library(GSEABase)
library(enrichplot)
library(clusterProfiler)
library(org.Mm.eg.db)

# 读取文件
DEG <- read.table(file = "GSE158995_DEG_all.txt",header = T,sep = "\t")

# 建立genelist
geneList <- DEG$log2FoldChange
names(geneList) <- DEG$ENTREZID
geneList <- sort(geneList, decreasing = T)
geneList <- geneList[geneList != 0]

#GSEA分析
set.seed(1234)
egmt <- gseKEGG(geneList, organism = "mmu", pvalueCutoff = 1,nPermSimple = 1000000)

gsea_results <- egmt@result

# 筛选富集结果
# 感觉假阳性有点高，padjust和qvalue都比较高，而且存在一些值相同
gsea_results2 <- gsea_results[(gsea_results$NES > 1) | (gsea_results$NES < (-1)),] 

# 按照NES值降序排序，最重要的通路排在最前面
gsea_results2 <- gsea_results2[order(gsea_results2$NES, decreasing = T),]

# 导出
write.csv(x = gsea_results2,file = "./GSEA/GSE158995_GSEA富集.csv")


# GSEA可视化
library(sjPlot)
first_five_row <- gsea_results2[1:5,]
last_five_row <- tail(gsea_results2,5)
KEGGList <- rbind(first_five_row,last_five_row)
write.table(KEGGList,"./GSEA/GSE158995_GSEA_top5_UP&DOWN_KEGG.txt",sep = "\t",row.names = T,col.names = T,quote = F)
KEGGList <- KEGGList$"ID"

KEGGList

x <- "GSE158995"
p1 <- gseaplot2(egmt, 
                geneSetID = KEGGList, 
                subplots = 1:3,
                title = paste(paste0(substring(x, 1, 5), " ", substring(x, 6)),"KEGG Pathway"),
                base_size = 12,
                rel_heights = c(1.6, 0.4, 0.4))
p1
pdf("./GSEA/GSE158995_gseKEGG.pdf",width = 15,height = 15)
print(p1)
dev.off()





