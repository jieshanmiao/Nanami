setwd("D:/AD实训/RNAseq/RNAseq-1")
rm(list = ls())

# 加载必要的包
library(limma)
library(dplyr)
library(sva)
library(DESeq2)
library(clusterProfiler)
library(org.Mm.eg.db)

# 读取数据
data <- read.table("Mm_Cortex_RNA_Counts.txt", sep = '\t', header = T)

# 筛选并删除除第一列外，其他为0的列的数量不超过总数量（删去第一列后的）的20%的行
data_org <- data %>%
  mutate(zero_count = rowSums(.[, -1] == 0)) %>%
  filter(zero_count <= 0.2 * (ncol(.) - 1)) %>%
  dplyr::select(-zero_count) 

# 合并重复行
data_org <- avereps(data_org, data_org$gene)

data_org <- as.data.frame(data_org)

# 取genename为行名
rownames(data_org) <- data_org$gene
data_org <- data_org[ , -1]
dim(data_org) 


#####差异分析#####
# 根据治疗信息分组，取出对应的列
data_SD <- data_org[, c(1:4)]
data_KD <- data_org[, c(5:7)]

group <- c(rep('SD', ncol(data_SD)), rep('KD', ncol(data_KD)))
group <- factor(group, levels = c("SD", "KD"))

table(group)

# 创建一个数据框用于存储样本的分组信息，行名为样本名，列名为分组信息
colData <- data.frame(row.names = colnames(data_org),
                      group = group)
colData$group <- factor(colData$group, levels = c("SD", "KD"))
head(colData)

# 过程中遇到非数值类型（实际是原始count，应该都是整数），做强制转换
# 检查data_org中每一列的数据类型，并尝试转换非数值型数据
data_org1 <- data.frame(lapply(data_org, function(x) {
  # 检查数据类型
  if (!is.numeric(x)) {
    # 尝试将非数值型数据转换为数值型
    as.integer(as.character(x))
  } else {
    x
  }
}))

# 再次检查是否有非数值型数据
any_non_numeric <- any(sapply(data_org1, function(x) any(!is.numeric(x))))
print(any_non_numeric) 

# 构建DESeqDataSet对象，将基因计数数据、样本分组信息和设计矩阵关联起来
dds <- DESeqDataSetFromMatrix(countData = data_org1, # 表达矩阵
                              colData = colData,
                              design = ~ group)
head(dds)

# 进行差异表达分析
dds <- DESeq(dds)

res <- results(dds, contrast = c("group", rev(levels(group))))

# 按照padj（调整后的p值）的大小对差异结果进行排序
resOrdered <- res[order(res$padj), ]

# 将差异表达结果转换为数据框
DEG <- as.data.frame(resOrdered)
rownames(DEG) <- rownames(data_org)

# 去除缺失值，如果没有这一步，一些表达量很低的基因计算后会出现NA，给后续分析和绘图带来麻烦，远离麻烦！
DEG_deseq2 <- na.omit(DEG)

# 将处理后的差异表达结果保存为R数据文件
save(DEG_deseq2, file = './GSE230469_DEG_deseq2.Rdata')

# 这里看res里，padj没有很显著的，可能是因为是小鼠模型，数据量不大
#不清楚后续画图的同学如何选择，所以把pvalue也加进来
DEG_res = DEG_deseq2[,c(2,5,6)]
colnames(DEG_res) = c('log2FoldChange','pvalue','padj')


#####--后续分析数据处理--#####
# ID转换
DEG_res$symbol <- row.names(DEG_res)
map <- bitr(DEG_res$symbol, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Mm.eg.db, drop = TRUE)
#提示少量无法映射

DEG_res <- merge(DEG_res,map,by.x = "symbol",by.y = "SYMBOL")

# 筛选上调下调基因
DEG_res$Group <- ifelse(DEG_res$log2FoldChange > 1,"Up",ifelse(DEG_res$log2FoldChange<(-1),"Down","none"))
head(DEG_res)
table(DEG_res$Group)

# 关联分析数据准备
DEG_res <- DEG_res %>% dplyr::select("ENTREZID", "symbol", "log2FoldChange", "pvalue", "padj", "Group")

# 存数据用于后续分析
# 所有基因结果
write.table(DEG_res, file = "GSE230469_DEG_all.txt", sep = "\t")

# 差异基因结果
up_down <- DEG_res %>% filter(Group == "Up" | Group == "Down")
write.table(up_down, file = "GSE230469_DEG_Up_Down.txt", sep = "\t")



#####--GO富集分析--#####
# 用的是Mus musculus
library(org.Mm.eg.db)
library(clusterProfiler)
library(DOSE)

#差异基因集提取
up <- DEG_res[,1][DEG_res$Group == "Up"]#差异上调
down <- DEG_res[,1][DEG_res$Group == "Down"]#差异下调

#所有差异基因的ENTREZID
diff <- c(up, down)

#查看可转换的ID类型
columns(org.Mm.eg.db)

# GO富集
GO_all_diff <- enrichGO(gene = diff,
                        OrgDb = org.Mm.eg.db,
                        ont = "ALL", 
                        pAdjustMethod = "BH",
                        pvalueCutoff = 0.05,
                        qvalueCutoff = 0.05,
                        minGSSize = 10,
                        maxGSSize = 500,
                        readable = T)

View(GO_all_diff@result)

# 导出
write.csv(x = GO_all_diff,file = "GSE230469_GO富集注释.csv")


#####--基因集富集分析--#####
rm(list = ls())
library(GSEABase)
library(enrichplot)
library(clusterProfiler)
library(org.Mm.eg.db)

# 读取文件
DEG <- read.table(file = "GSE230469_DEG_all.txt",header = T,sep = "\t")

# 建立genelist
geneList <- DEG$log2FoldChange
names(geneList) <- DEG$ENTREZID
geneList <- sort(geneList, decreasing = T)
geneList <- geneList[geneList != 0]

#GSEA分析
set.seed(1234)
egmt <- gseKEGG(geneList, organism = "mmu", pvalueCutoff = 1,nPermSimple = 1000000)

gsea_results <- egmt@result

# 筛选富集结果
gsea_results2 <- gsea_results[(gsea_results$NES > 1) | (gsea_results$NES < (-1)),] 

# 按照NES值降序排序，最重要的通路排在最前面
gsea_results2 <- gsea_results2[order(gsea_results2$NES, decreasing = T),]

# 导出
write.csv(x = gsea_results2,file = "./GSEA/GSE230469_GSEA富集.csv")
# 感觉假阳性有点高，padjust和qvalue都比较高

# GSEA可视化
library(sjPlot)
first_five_row <- gsea_results2[1:5,]
last_five_row <- tail(gsea_results2,5)
KEGGList <- rbind(first_five_row,last_five_row)
write.table(KEGGList,"./GSEA/GSE230469_GSEA_top5_UP&DOWN_KEGG.txt",sep = "\t",row.names = T,col.names = T,quote = F)
KEGGList <- KEGGList$"ID"

KEGGList

x <- "GSE230469"
p1 <- gseaplot2(egmt, 
                geneSetID = KEGGList, 
                subplots = 1:3,
                title = paste(paste0(substring(x, 1, 5), " ", substring(x, 6)),"KEGG Pathway"),
                base_size = 12,
                rel_heights = c(1.6, 0.4, 0.4))
p1
pdf("./GSEA/GSE230469_gseKEGG.pdf",width = 15,height = 15)
print(p1)
dev.off()




