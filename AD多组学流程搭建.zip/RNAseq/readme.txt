原始文件：original data

GSE信息：
_series_matrix.txt

读入信息：
RNAseq-1：Mm_Cortex_RNA_Counts.txt
RNAseq-2：GSE158995_mRNA_normalized.txt
RNAseq-3：GSE203554_normalised_borchelt_final.txt

脚本：
RNAseq-1：GSE230469_RNAseq1.R
RNAseq-2：GSE158995_RNAseq2.R
RNAseq-3：GSE203554_RNAseq3.R

差异分析结果：
RNAseq-1：GSE230469_DEG_deseq2.Rdata
RNAseq-2：GSE158995_DEG_limma.Rdata
RNAseq-3：GSE203554_DEG_limma.Rdata

差异分析（log2FC、pvalue、padjust）：
_DEG_all.txt

差异分析up&down（log2FC、pvalue、padjust）：
_DEG_Up_Down.txt

GO富集注释：
_GO富集注释.csv

GSEA分析：
_GSEA_top5_UP&DOWN_KEGG.txt
_GSEA富集.csv
_gseKEGG.pdf



