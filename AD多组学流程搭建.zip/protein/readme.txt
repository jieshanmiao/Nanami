原始文件：original data
alzjjalz201810006-sup-0002.xlsx
alzjjalz201810006-sup-0003.xlsx
alzjjalz201810006-sup-0004.xlsx
alzjjalz201810006-sup-0005.xlsx

整理后读入文件：（只保留SPR和WT，共3组）
AD_SPR_WT_control_norm.txt

脚本：
prot_analysis.R

差异分析结果：
DEP_limma.Rdata

差异分析（log2FC、pvalue、padjust）：
Prot_DEP_all.txt

差异分析up&down（log2FC、pvalue、padjust）：
Prot_DEP_Up_Down.txt

GO富集注释：
prot_GO富集注释.csv

