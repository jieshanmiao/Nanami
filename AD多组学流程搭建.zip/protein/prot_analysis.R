setwd("D:/AD实训/protein")
rm(list = ls())


# 加载必要的库
library(limma)
library(org.Mm.eg.db)

# 读取蛋白表达数据
data_prot <- read.table("AD_SPR_WT_control_norm.txt", header = T,sep = '\t')

# 处理缺失值
data_prot <- na.omit(data_prot)

# 取Accession为行名
rownames(data_prot) <- data_prot$Accession
data_prot <- data_prot[ , -1]

# 对数处理
data_prot <- log2(data_prot + 1)


#####--差异分析--#####
# 创建group，包含样本分组信息的列
group <- c("SPR","SPR","WT")
group <- factor(group, levels = c("SPR","WT"))
table(group)

# 创建设计矩阵，指定组别信息
design <- model.matrix(~0 + factor(group))
colnames(design) = levels(factor(group))
rownames(design) = colnames(data_prot)

# 检查数据类型，确保所有列都是数值型
str(data_prot)

# 使用线性模型进行拟合
fit <- lmFit(data_prot, design)

# 说明是谁比谁
con <- paste(levels(group), collapse = "-")
con

# 创建对比矩阵
cont.matrix <- makeContrasts(contrasts = c(con), levels = design)
fit2 <- contrasts.fit(fit, cont.matrix)
fit2 <- eBayes(fit2)

# 获取差异表达蛋白结果
tempOutput <- topTable(fit2, coef = con, n = Inf)

# 去除缺失值
DEP_limma <- na.omit(tempOutput)
head(DEP_limma)

# 将差异表达基因结果保存到 Rdata 文件中
save(DEP_limma, file = './DEP_limma.Rdata')

# padj非常显著
# 不清楚后续画图的同学如何选择，所以把pvalue也加进来
DEP_res = DEP_limma[,c(1,4,5)]
colnames(DEP_res) = c('log2FoldChange', 'pvalue', 'padj')


#####--后续分析数据处理--#####
# ID转换
DEP_res$symbol <- row.names(DEP_res)
map <- bitr(DEP_res$symbol, fromType = "UNIPROT", toType = "ENTREZID", OrgDb = org.Mm.eg.db, drop = TRUE)
#提示少量无法映射

DEP_res <- merge(DEP_res,map,by.x = "symbol",by.y = "UNIPROT")

# 筛选log2FoldChange
DEP_res$Group <- ifelse(DEP_res$log2FoldChange > 1,"Up",ifelse(DEP_res$log2FoldChange<(-1),"Down","none"))
head(DEP_res)
table(DEP_res$Group)

# 关联分析数据准备
DEP_res <- DEP_res %>% select("ENTREZID", "symbol", "log2FoldChange", "pvalue", "padj", "Group")

# 存数据用于后续分析
# 所有蛋白结果
write.table(DEP_res, file = "Prot_DEP_all.txt", sep = "\t")

# 差异蛋白结果
up_down <- DEP_res %>% filter(Group == "Up" | Group == "Down")
write.table(up_down, file = "Prot_DEP_Up_Down.txt", sep = "\t")



#####--GO富集分析--#####
# 用的是Mus musculus
library(org.Mm.eg.db)
library(clusterProfiler)
library(DOSE)

#差异蛋白集提取
up <- DEP_res[,1][DEP_res$Group == "Up"]#差异上调
down <- DEP_res[,1][DEP_res$Group == "Down"]#差异下调

#所有差异蛋白的ENTREZID
diff <- c(up, down)

#查看可转换的ID类型
columns(org.Mm.eg.db)

# GO富集
GO_all_diff <- enrichGO(gene = diff,
                        OrgDb = org.Mm.eg.db,
                        ont = "ALL", 
                        pAdjustMethod = "BH",
                        pvalueCutoff = 0.05,
                        qvalueCutoff = 0.05,
                        minGSSize = 10,
                        maxGSSize = 500,
                        readable = T)

View(GO_all_diff@result)

# 导出
write.csv(x = GO_all_diff,file = "prot_GO富集注释.csv")





