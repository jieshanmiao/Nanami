GSE230469
差异基因的条件：abs(logFC)>1 & pvalue<0.05
富集图选择基因的条件：abs(logFC)>1  （因为差异基因较少，所以宽松范围）

GSE158995
差异基因的条件：abs(logFC)>1 & pvalue<0.05
富集图选择基因的条件：abs(logFC)>3 （因为差异基因较多，所以严格范围）

GSE203554
差异基因的条件：abs(logFC)>1 & pvalue<0.05
富集图选择基因的条件：abs(logFC)>0.8 （log2FC选的0.8，跟其他两个集接近的DEG，选1偏少）

Protein
差异基因的条件：abs(logFC)>1 & pvalue<0.05
富集图选择基因的条件：abs(logFC)>1  （因为差异基因较少，所以宽松范围）



作图如下：


1. 火山图 
data（3列）：差异基因、logFC、pvalue

2. 热图
data1：差异基因 
data2：差异基因表达量 
data3：分组情况 

3. 箱线图 
data1：上调基因top3表达量 
data2：下调基因top3表达量 

4. PCA
data1：基因表达量 
data2：分组情况 

5. 富集图	
5.1 GO 
data：差异基因 
5.2 KEGG	 
data：差异基因

6. 网络图	
data：差异基因 
GSE230469：medium confidential（0.400）
GSE158995：high confidential（0.700） （由于各个点之间关联较多，设置较高置信度）
GSE203554：medium confidential（0.400）
Protein：high confidential（0.700） （由于各个点之间关联较多，设置较高置信度）